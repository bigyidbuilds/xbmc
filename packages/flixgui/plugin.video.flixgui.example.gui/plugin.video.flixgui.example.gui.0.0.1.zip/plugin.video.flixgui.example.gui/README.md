# plugin.video.flixgui.example.gui

xbmc Plugin example for using xbmc FlixGui Script

[script.gui.flixgui](https://github.com/bigyidbuilds/script.gui.flixgui#scriptguiflixgui)


[Example file for movie playlist](https://github.com/bigyidbuilds/plugin.video.flixgui.example.basic/blob/20842b0450692c75a9b9559d84ec34677800f4b2/_playlist_example/movies.json)
 
[Example file for tv playlist](https://github.com/bigyidbuilds/plugin.video.flixgui.example.basic/blob/20842b0450692c75a9b9559d84ec34677800f4b2/_playlist_example/tvshows.json)