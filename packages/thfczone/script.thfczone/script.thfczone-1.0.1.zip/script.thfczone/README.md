# script.thfczone
 Xbmc/Kodi Addon for Spurs fans

## Installation via THFC Zone Repository 

https://bigyidbuilds.github.io 

### Version Updates

- V1.0.1
    Added new season 2021-2022
- V1.0.0
    Updated for Kodi 19