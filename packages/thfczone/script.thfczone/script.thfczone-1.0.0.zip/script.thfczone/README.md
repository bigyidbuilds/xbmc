# script.thfczone
 Xbmc/Kodi Addon for Spurs fans

## Installation via THFC Zone Repository 

https://bigyidbuilds.github.io 