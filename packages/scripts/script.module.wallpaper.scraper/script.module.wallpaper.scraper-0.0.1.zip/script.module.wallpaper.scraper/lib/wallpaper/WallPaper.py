#!/usr/bin/python3
# -*- coding: utf-8 -*-

import os
import traceback
from collections import Counter


from .scrapers import * 
from .modules import *


ADDON = Addon('script.module.wallpaper.scraper')

path = os.path.join(ADDON.PATH,'lib','wallpaper','scrapers')

def GetWallPapers(query,most_common_limit=10):
	results = {}
	items = []
	keywords = []
	_sources = sources(path,'scrapers')
	for mk,mv in _sources.items():
		module = import_module(mv.get('module_fullname'),'wallpaper')
		module_classes = pyreader(mv.get('module_path'))
		for ck,cv in module_classes.items():
			try:
				class_name = cv.get('class_name')
				if 'scrape' in cv.get('def_names'):
					s = getattr(module,class_name)(query)
					scrape_content = s.scrape()
					for s in scrape_content:
						keywords += s.get('keywords')                   
					items += scrape_content
			except Exception as e:
				Log(F'{e} {traceback.print_exc()}')
	if len(keywords)>0:
		kw_count_dict = dict((x,keywords.count(x)) for x in set(keywords))
		kw_most_common = dict(Counter(kw_count_dict).most_common(most_common_limit))
	else:
		kw_most_common = {}
	results.update({"results":{"items":items,"total_items":len(items),"keywords":kw_most_common}})
	return results
