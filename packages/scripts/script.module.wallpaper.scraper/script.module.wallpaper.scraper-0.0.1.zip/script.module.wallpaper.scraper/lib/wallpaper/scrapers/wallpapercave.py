#!/usr/bin/python3
# -*- coding: utf-8 -*-


import requests
from bs4 import BeautifulSoup 
from urllib.parse import urlunparse,urlencode,quote_plus
import time

try:
	from wallpaper.modules import scraperutils
except:pass

class Wallpapercave(object):

	def __init__(self,query):
		super(Wallpapercave, self).__init__()
		self.scheme = 'https'
		self.netloc = 'wallpapercave.com'
		self.searchpath = 'search?q={}'
		self.query = query
		self.cleanquery = quote_plus(self.query)
		self.useragent = 'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36'
		self.accept = '*/*'
		self.acceptlanguage = 'en-US,en;q=0.9'
		self.referer = urlunparse((self.scheme,self.netloc,'',None,None,None))
		self.headers = {
						'user-agent':self.useragent,
						'accept':self.accept,
						'accept-language':self.acceptlanguage,
						'referer':self.referer
						}


	def searchurl(self):
		urls = list()
		url = urlunparse((self.scheme,self.netloc,self.searchpath.format(self.cleanquery),None,None,None))
		res = requests.get(url,headers=self.headers)
		soup = BeautifulSoup(res.content, 'html.parser')
		popular = soup.find('div',{'id':'popular'})
		albumphoto = popular.find_all('div',{'class':'albumphoto'})
		for c in albumphoto:
			urls.append(c.get('href'))
		return urls
		


	def scrape(self):
		items = list()
		urls = self.searchurl()
		for u in urls:
			url = urlunparse((self.scheme,self.netloc,u,None,None,None))
			res = requests.get(url,headers=self.headers)
			soup = BeautifulSoup(res.content, 'html.parser')
			item = soup.find_all('div',{'class':'wallpaper'})
			for i in item:
				picture = i.find('picture')
				img = picture.find('img')
				name = img.get('alt')
				imglink = img.get('src')
				img_w = img.get('width')
				img_h = img.get('height')
				img_url = urlunparse((self.scheme,self.netloc,imglink,None,None,None))
				try:
					name_kw = scraperutils.keywords(name,self.query)
				except:
					name_kw = {}
				items.append({'label':name,'url':img_url,'source':self.netloc,"keywords":name_kw,"height":img_h,"width":img_w})
			time.sleep(1)
		return items




# if __name__ == '__main__':
# 	print(Wallpapercave('tottenham hotspur').scrape())