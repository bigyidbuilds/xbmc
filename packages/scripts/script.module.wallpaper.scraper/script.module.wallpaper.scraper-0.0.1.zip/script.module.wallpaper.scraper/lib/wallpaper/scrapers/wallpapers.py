#!/usr/bin/python3
# -*- coding: utf-8 -*-
import requests
from bs4 import BeautifulSoup 
import re
from urllib.parse import urlunparse,urlencode,quote_plus
try:
	from wallpaper.modules import scraperutils
except:pass
import time

class Wallpapers(object):
	"""docstring for Wallpapers"""
	def __init__(self, query):
		super(Wallpapers, self).__init__()
		self.scheme = 'https'
		self.netloc = 'wallpapers.com'
		self.searchpath = 'search?scope=wallpapers&q={}'
		self.query = query
		self.cleanquery = quote_plus(self.query)
		self.useragent = 'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36'
		self.accept = '*/*'
		self.acceptlanguage = 'en-US,en;q=0.9'
		self.referer = urlunparse((self.scheme,self.netloc,'',None,None,None))
		self.headers = {
						'user-agent':self.useragent,
						'accept':self.accept,
						'accept-language':self.acceptlanguage,
						'referer':self.referer
						}


	def geturls_from_search(self):
		_urls = []
		url = urlunparse((self.scheme,self.netloc,self.searchpath.format(self.cleanquery),None,None,None))
		res = requests.get(url,headers=self.headers)
		soup = BeautifulSoup(res.content, 'html.parser')
		main = soup.find('main',{'class':"ad-enabled"})
		url_block = main.find_all('a')
		for a in url_block:
			url = a.get('href')
			if url not in _urls:
				_urls.append(url)
		return _urls


	def nextpage_loop(self,url):
		url = urlunparse((self.scheme,self.netloc,url,None,None,None))
		loopitems = []
		error_counter = 0
		while True:
			print(f'looping {error_counter} {url}') 
			res = requests.get(url,headers=self.headers)
			if not res.status_code == requests.codes.ok:
				break
			soup = BeautifulSoup(res.content, 'html.parser')
			kw_contents = soup.find('ul',{'class':"kw-contents"})
			if kw_contents:
				content = kw_contents.find_all('li',{"class":"content-card horizontal"})
				for c in content:
					try:
						name = scraperutils.cleanlabel(c.find('figcaption').text)
					except:
						name = c.find('figcaption').text
					img = c.find('img')
					img_url = img.get('src')
					img_h = img.get('height')
					img_w = img.get('width')
					try:
						name_kw = scraperutils.keywords(name,self.query)
					except:
						name_kw = {}
					loopitems.append({'label':name,'url':img_url,'source':self.netloc,"keywords":name_kw,"height":img_h,"width":img_w})
				nextpage = kw_contents.find('li',{"class":"content-card endpoint"})
				nextpage_title = nextpage.text
				if 'next' in nextpage.text.lower() :
					url = urlunparse((self.scheme,self.netloc,nextpage.find('a').get('href'),None,None,None))
				else:
					break
			elif error_counter > 5:
				break
			else:
				error_counter +=1
		return loopitems


	def scrape(self):
		urls = self.geturls_from_search()
		items = []
		time.sleep(1)
		for url in urls:
			items += self.nextpage_loop(url)
			time.sleep(1)
		return items
			




if __name__ == '__main__':
	r = Wallpapers('tottenham hotspur')
	print(r.scrape())


