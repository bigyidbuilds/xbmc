#!/usr/bin/python3
# -*- coding: utf-8 -*-

import ast


def pyreader(filepath):
	_cls = {}
	with open(filepath) as file:
		node = ast.parse(file.read())

	classes = [n for n in node.body if isinstance(n, ast.ClassDef)]

	for class_ in classes:
		_def = []
		class_name = class_.name
		methods = [n for n in class_.body if isinstance(n, ast.FunctionDef)]
		for method in methods:
			_def.append(method.name)
		_cls.update({class_name:{"class_name":class_name,"def_names":_def}})
	return _cls


