#!/usr/bin/python3
# -*- coding: utf-8 -*-

import os



__all__ = ['sources']


def sources(basepath,parent_name):
	_sources = {}
	for module_from_path in _modules_from_path(basepath):
		module_name = os.path.splitext(os.path.basename(module_from_path))[0]
		module_fullname = f'.{parent_name}.{module_name}'
		_sources.update({module_name:{'module_path':module_from_path,'module_fullname':module_fullname}})
	return _sources



def _modules_from_path(directory_path):
	return [os.path.join(directory_path,file) for file in os.listdir(directory_path) if os.path.isfile(
		os.path.join(directory_path, file))and not file.endswith('__init__.py')]





