#!/usr/bin/python3
# -*- coding: utf-8 -*-

import re


def keywords(label,query):
	remove = [
			'a',
			'and',
			'on',
			'of',
			'off',
			'in',
			'the',
			'with',
			'desktop'
			]


	label = label.replace(',',' ')
	remove_compile = [
					r'(?<!\S)[0-9]+x[0-9]+(?!\S)',
					r'wallpaper.*?$',
					r'background.*?$']

	for q in query.lower().split():
		remove_compile.append(r'{}.*?$'.format(q))



	label_list = label.lower().split()
	compiled_str = '|'.join( remove_compile)
	removed_list = [w for w in label_list if w not in re.compile( compiled_str ).findall(w) and w not in remove ]
	return [w for w in removed_list if len(w)>2]

def cleanlabel(label):
	return " ".join(label.split())




