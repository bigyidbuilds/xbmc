# script.module.wallpaper.scraper

## Example code to call scrapers
```
	import wallpaper

	results = wallpaper.GetWallPapers(search_queary)
```

## Return from scraper

return from scraper is a dict containing

Example

```
	{"results":
			{
				"items":
					[
						{
							"label":name of image,
							"url":imgage url,
							"source":scraper url,
							"keywords":keywords from image name,
							"height":imgage height,
							"width":imgage width
						}
					],
				"total_items":total items returned,
				"keywords":most common keywords from titles of items
			}
	}
```

