# UserGuide

## Categories

### To Hide a category

To hide a category, focus on category and call context menu or right click on category and select Hide Category

### Un-hide Category

Go in to settings and select Categories and Channels editor, then edit Hidden where you can unselect the category or categories you wish to see again 

## Channels

### To Hide Channel

To hide a channel, focus on channel and call context menu or right click on category and select Hide Channel

### Un-Hide Channel

Go in to settings and select Categories and Channels editor, then edit Hidden where you can unselect the channel or channels you wish to see again 

### Add to myFavorites

To add a channel to myFavorites focus on channel and call context menu or right click on channel and select add to myFavorites **This is a addon contained Favorites different from Kodi favorites**

## myFavorites

### Remove myFavorite

To remove a channel from myFavorites focus on the Favorite in myFavorites and call context menu or right click on Favorite and select remove from myFavorites
